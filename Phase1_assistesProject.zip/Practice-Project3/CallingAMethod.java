package assistedPractice;

public class CallingAMethod {
	static int Sub;
	public int a,b;
	int Subract(int a,int b) {
		Sub=a-b;
		return Sub;
	}
	public static void main(String args[])
	{
		CallingAMethod objct=new CallingAMethod();
		objct.a=5;
		objct.b=1;
		objct.Subract(objct.a,objct.b);
		//call by reference
		System.out.println("The difference of the given number is "+Sub);
	}

}
