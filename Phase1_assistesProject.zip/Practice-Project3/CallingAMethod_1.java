package assistedPractice;

public class CallingAMethod_1 {
	static int Sub;
	int Subract(int a,int b) {
		Sub=a-b;
		return Sub;
	}
	public static void main(String args[])
	{
		CallingAMethod objct=new CallingAMethod();
		int a=10;
		objct.Subract(objct.a,objct.b);
		//call by reference
		System.out.println("The difference of the given number is "+Sub);
	}

}
