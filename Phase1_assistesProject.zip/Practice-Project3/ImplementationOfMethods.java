package assistedPractice;

public class ImplementationOfMethods {
	int result;
	public int sum(int a,int b) {
		result=a+b;
		return result;
	}
	public static void main(String args[]) {
		int a,b,z;
		ImplementationOfMethods obj=new ImplementationOfMethods();
		z=obj.sum(5,6);
		System.out.println("Sum of given numbers is "+z);
	}

}
