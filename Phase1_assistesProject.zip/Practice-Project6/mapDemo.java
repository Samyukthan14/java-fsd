package assistedPractice;


import java.util.*;
public class mapDemo {

	public static void main(String[] args) {
		
		//Hashmap
		HashMap<Integer,String> hashm=new HashMap<Integer,String>();      
	      hashm.put(1,"Ram");    
	      hashm.put(2,"Suriya");    
	      hashm.put(3,"Jack"); 
	      hashm.put(4,"Gautham");  
	       
	      System.out.println("\nThe elements of Hashmap are:");  
	      for(Map.Entry m:hashm.entrySet()){    
	       System.out.println(m.getKey()+" "+m.getValue());    
	      }
	      
	     //HashTable
	       
	      Hashtable<Integer,String> hash=new Hashtable<Integer,String>();  
	      hash.put(5,"Hari");  
	      hash.put(6,"Fabrize");  
	      hash.put(7,"Priya");  

	      System.out.println("\nThe elements of HashTable are: ");  
	      for(Map.Entry n:hash.entrySet()){    
	       System.out.println(n.getKey()+" "+n.getValue());    
	      }
	      
	      
	      //TreeMap
	      
	      TreeMap<Integer,String> tree=new TreeMap<Integer,String>();    
	      tree.put(8,"Revathi");    
	      tree.put(9,"Anusha");    
	      tree.put(10,"Keethi");       
	      
	      System.out.println("\nThe elements of TreeMap are: ");  
	      for(Map.Entry l:tree.entrySet()){    
	       System.out.println(l.getKey()+" "+l.getValue());    
	      }    
	      
	   }  
}