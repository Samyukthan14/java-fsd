package assistedPractice_1;
import assistedPractice.AccessModifiers_3;

public class AccessModifiers_3_1 extends AccessModifiers_3{
	public static void main(String args[]) {
		System.out.println("Protected");
		AccessModifiers_3_1 object=new AccessModifiers_3_1();
		object.display();
	}

}
