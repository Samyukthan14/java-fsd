package assistedPractice;

class AccessModifiers {
	void display() {
		System.out.println("The Default Access Modifier is used.");
	}
	public static void main(String args[]) {
		System.out.println("Default");
		AccessModifiers object=new AccessModifiers();
		object.display();
	}
	

}
