package assistedPractice;

public class AccessModifiers_2 {
	public void display() {
		System.out.println("The Public Access Modifier is used.");
	}

}