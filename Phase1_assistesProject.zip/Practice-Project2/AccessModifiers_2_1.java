package assistedPractice_1;

import assistedPractice.AccessModifiers_2;
public class AccessModifiers_2_1 extends AccessModifiers_2{
	public static void main(String args[]) {
		System.out.println("Public");
		AccessModifiers_2 object=new AccessModifiers_2();
		object.display();
}

}