package assistedPractice;

public class AccessModifiers_3 {
	protected void display() {
		System.out.println("The Protected Access Modifier is used.");
	}

}
