package assistedPractice;

class AccessModifier {
	private void display() {
		System.out.println("The Private Access Modifier is used.");
	}
}
public class AccessModifiers_1{
	public static void main(String args[]) {
		System.out.println("Private");
		AccessModifier object=new AccessModifier();
	//	object.display();
}
}