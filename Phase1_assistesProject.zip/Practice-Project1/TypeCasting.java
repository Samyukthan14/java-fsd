package assistedPractice;

public class TypeCasting {
	public static void main(String args[]) {
		System.out.println("Implicit Typecasting:");
		char a='A';
		System.out.println("The value of a is "+a);
		int b=a;
		System.out.println("The value of b is "+b);
		float c=a;
		System.out.println("The value of c is "+c);
		double d=a;
		System.out.println("The value of d is "+d);
		long e=a;
		System.out.println("The value of b is "+e);
		
		System.out.println("\nExplicit Typecasting:");
		double y=24;
		System.out.println("The value of y is "+y);
		int z=(int)y;
		System.out.println("The value of z is "+z);
	}

}
