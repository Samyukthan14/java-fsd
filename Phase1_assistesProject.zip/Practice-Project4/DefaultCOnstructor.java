package assistedPractice;

public class DefaultCOnstructor {
	int id;
	String name;
	void show()
	{
		System.out.println("ID: "+" "+"Name: ");
	}
}
class Stud
{
	public static void main(String args[]) {
		DefaultCOnstructor stud1=new DefaultCOnstructor();
		DefaultCOnstructor stud2=new DefaultCOnstructor();
		stud1.show();
		stud2.show();

	}
}