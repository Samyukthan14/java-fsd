package assistedPractice;

public class ParameterizedConstructor {
	int ID;
	String Name;
	ParameterizedConstructor(int i,String n){
		ID=i;
		Name=n;
	}
	void show() {
		System.out.println("ID: "+ID+"Name: "+Name);
	}
	
	
}
class Employee{
	public static void main(String args[]) {
	ParameterizedConstructor Emplo1=new ParameterizedConstructor(1,"Sam");
	Emplo1.show();
	ParameterizedConstructor Emplo2=new ParameterizedConstructor(2,"John");
	Emplo2.show();
	}
	
}
