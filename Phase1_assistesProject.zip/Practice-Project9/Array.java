package assistedPractice;

public class Array {
	public static void main(String args[]) {
		int i;
		int a[]= {2,5,1,9};
		System.out.println("The elements in the array are: ");
		for(i=0;i<4;i++)
			System.out.println(a[i]);
		int b[][]= {{1,2,3},{3,2,1,0}};
		System.out.println("\nLength of row 1: " + b[0].length);
		System.out.println("\nLength of row 2: " + b[1].length);
		}
	}

