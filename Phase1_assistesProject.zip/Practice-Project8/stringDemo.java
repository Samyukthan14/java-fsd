package assistedPractice;

public class stringDemo {

	public static void main(String[] args) {
		
		String sl=new String("Hello");
		System.out.println(sl.length());

		String s1="Hello";
		String s2="World";
		String s5="Hello";
		String s6="Heldo";
		
		//substring
		String substr=new String("All the best");
		System.out.println(substr.substring(8));

		//IsEmpty
		String s4="Empty";
		System.out.println(s4.isEmpty());

		//toLowerCase
		System.out.println(s1.toLowerCase());
		
		//toUpperCase
		System.out.println(s1.toUpperCase());
		
		//replace
		String replace=s1.replace('l', 'o');
		System.out.println(replace);


		System.out.println("\nCreating StringBuffer:");
		//Creating StringBuffer and append method
		StringBuffer s=new StringBuffer("Thank you!");
		s.append("Have a nice day!");
		System.out.println(s);

		//insert method
		s.insert(0, '!');
		System.out.println(s);

		//replace method
		StringBuffer sb=new StringBuffer("Hello");
		sb.replace(0, 2, "hEl");
		System.out.println(sb);
		
		//StringBuilder
		System.out.println("\nCreating StringBuilder:");
		StringBuilder sb1=new StringBuilder("Welcome");
		sb1.append("Home");
		System.out.println(sb1);

		System.out.println(sb1.delete(0, 1));

		System.out.println(sb1.insert(1, "Welcome"));

		System.out.println(sb1.reverse());
				
		//conversion	
		String strng="Conversion of Strings into StringBuffer and StringBuilder";
		System.out.println("\n");
		System.out.println(strng.toUpperCase());
		
		String str = "Welcome"; 
        
        // conversion from String object to StringBuffer 
        StringBuffer sbr = new StringBuffer(str); 
        sbr.reverse(); 
        System.out.println("Converting String to StringBuffer:");
        System.out.println(sbr); 
          
        // conversion from String object to StringBuilder 
        StringBuilder sbl = new StringBuilder(str); 
        sbl.append("Home"); 
        System.out.println("Converting String to StringBuilder:");
        System.out.println(sbl);              		
	}
}