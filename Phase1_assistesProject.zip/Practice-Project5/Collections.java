package assistedPractice;
import java.util.*;
public class Collections {
	public static void main(String[] args) {
		System.out.println("ArrayList:");
		ArrayList<Integer> num=new ArrayList<Integer>();   
	      num.add(2);
	      num.add(3);
	      num.add(9);
	      System.out.println(num);  
		
	      
	      System.out.println("\nVector:");
	      Vector<Integer> number = new Vector<Integer>();
	      number.addElement(10); 
	      number.addElement(20); 
	      number.addElement(30); 
	      System.out.println(number);
		
	      
	      System.out.println("\nLinkedList:");
	      LinkedList<String> names=new LinkedList<String>();  
	      names.add("Sona");  
	      names.add("John");  	      
	      Iterator<String> itr=names.iterator();  
	      while(itr.hasNext()){  
	       System.out.println(itr.next());  
	       

	       System.out.println("\nHashSet:");
	       HashSet<Integer> set=new HashSet<Integer>();  
	       set.add(101);  
	       set.add(104);  
	       set.add(102);
	       set.add(104);
	       System.out.println(set);
	       

	       System.out.println("\nLinkedHashSet:");
	       LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
	       set2.add(11);  
	       set2.add(13);  
	       set2.add(11);
	       set2.add(10);	       
	       System.out.println(set2);
	      	} 
	      }  
}
