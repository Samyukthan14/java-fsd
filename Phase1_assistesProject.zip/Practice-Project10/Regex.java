package assistedPractice;
import java.util.regex.*;

public class Regex {
	public static void main(String args[]) {
		String pattern="[a-z A-Z]+";
		String matching="Welcome";
		Pattern p=Pattern.compile(pattern);
		Matcher m=p.matcher(matching);
		
		boolean result=m.matches();
		System.out.println(result);
		
	}

}
