package assistedPractice;

public class TryCatch {
	public static void main(String args[]) {
		int a=7,b=0;
		
		try {
			System.out.println(a/b);
		}
		catch(ArithmeticException e)
		{
			
			System.out.println("Any number divided by 0 is invalid.");
		}
		finally {
			System.out.println("The operation is invalid.");
		}
	}

}
