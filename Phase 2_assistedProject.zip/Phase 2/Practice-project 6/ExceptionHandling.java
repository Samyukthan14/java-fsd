package assistedPractice;
public class ExceptionHandling {
	public static void main(String args[]) {
		int arr[]= new int[2];
		try
		{
			arr[10]=4;
		}
		catch(Exception e)
		{
			System.out.println("Array out of index");
		}
	}

}
