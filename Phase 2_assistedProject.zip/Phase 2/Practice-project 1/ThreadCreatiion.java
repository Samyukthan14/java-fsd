package assistedPractice;
class trd implements Runnable{
	public void run() {
		System.out.println("Runnable");
	}
	
}
class thrd extends Thread{
	public void run() {
			System.out.println("The thread is running!");
	}
}

public class ThreadCreatiion {
	public static void main(String args[]) {
	thrd a=new thrd();
	a.start();
	Runnable trd=new trd();
	Thread t1=new Thread(trd);
	t1.start();
	}

}