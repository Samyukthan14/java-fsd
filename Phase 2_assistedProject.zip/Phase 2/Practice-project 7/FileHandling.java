package assistedPractice;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class FileHandling {
	public static void main(String args[]) throws IOException{
		File myFile=new File("Assisted Practice file");
		if(myFile.createNewFile()) 
		{
			System.out.println("File created");
			
		}
		else
		{
			System.out.println("File already exists");
		}
		FileWriter toWrite=new FileWriter(myFile);
		toWrite.write("Welcome to the file");
		toWrite.close();
		if(myFile.canWrite())
			System.out.println("The file is Writable.");
		else
			System.out.println("The file is not Writable.");
		
		FileReader toRead=new FileReader(myFile);
		toRead.read();
		toRead.close();
		if(myFile.canRead())
			System.out.println("The file is readable.");
		else
			System.out.println("The file is not readable.");
		FileWriter writerFile=new FileWriter(myFile);
		BufferedWriter append=new BufferedWriter(writerFile);
		append.write("Hello!");
		append.close();
		writerFile.close();
		
	}

}
