package assistedPractice;



public class Classes 
{  
    String name; 
    String breed; 
    public Classes(String name, String breed) 
    { 
        this.name = name; 
        this.breed = breed; 
    } 
    public String Name() 
    { 
        return name; 
    } 
    public String Breed() 
    { 
        return breed; 
    } 

    public String toString() 
    { 
        return( this.Name()+"\n"+  this.Breed()); 
    } 
    public static void main(String[] args) 
    { 
        Classes Tintu = new Classes("Tintu","Shitzu"); 
        System.out.println(Tintu.toString()); 
    } 
}