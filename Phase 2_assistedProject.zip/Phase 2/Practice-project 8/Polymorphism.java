package assistedPractice;


class Polymorphism 
{
    public int sum(int x, int y) 
    { 
        return (x+y); 
    } 
    public int sum(int x, int y, int z) 
    { 
        return (x+y+z); 
    } 
    public double sum(double x, double y, double z) 
    { 
        return (x+y+z); 
    } 
    public static void main(String args[]) 
    { 
        Polymorphism add = new Polymorphism(); 
        System.out.println("Sum="+add.sum(2,3)); 
        System.out.println("Sum="+add.sum(1,2,3)); 
        System.out.println("Sum="+add.sum(0.5,4.7,1.5)); 
    } 
}