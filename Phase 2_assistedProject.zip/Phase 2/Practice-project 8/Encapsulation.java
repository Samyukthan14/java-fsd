package assistedPractice;

public class Encapsulation
{ 
    private String Name; 
    private int Age;
    public int getAge()  
    { 
      return Age; 
    } 
    public String getName()  
    { 
      return Name; 
    } 
    public void setAge( int newAge) 
    { 
      Age = newAge; 
    } 
    public void setName(String newName) 
    { 
      Name = newName; 
    } 
   
public class Student 
{     
    public static void main (String[] args)  
    { 
        Encapsulation s = new Encapsulation(); 
        s.setName("John"); 
        s.setAge(21); 
        System.out.println("My name is: " + s.getName()); 
        System.out.println("I am " + s.getAge()+" years old"); 
    } 
}
}