package assistedPractice;
class A
{
	void divide() throws ArithmeticException
	{
	int a=10,b=0;
	System.out.println(a/b);
	}
}

public class Throws
{
	public static void main(String args[])
	{
		A obj=new A();
		obj.divide();
	}
	

}