package assistedPractice;

public class Throw 
{
	public static void main(String args[])
	{
		int bal=500,withdraw=800;
		try
		{
		if(bal<withdraw)
			throw(new Exception());
		}
		catch(Exception e)
		{
			System.out.println("Low Balance");
		}
		finally
		{
			System.out.println("Successful");
		}
	}
}