package assistedPractice;

class A extends Thread{
	synchronized void multiple(int n)
	{
		int i;
		for(i=1;i<=5;i++)
			System.out.println(i*n);
	}
}

public class Synchronized 
{
	public static void main(String args[]) 
	{
		A object=new A();
		Thread t1=new Thread()
		{
			public void run() 
			{
			object.multiple(5);
			}
		};
		
		Thread t2=new Thread()
		{
			public void run() 
			{
			object.multiple(10);
			}
		};
		
	    t1.start();
	    t2.start();
			
	}

}