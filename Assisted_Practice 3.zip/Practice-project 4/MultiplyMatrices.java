package assistedPractice;

public class MultiplyMatrices 
{
public static void main(String[] args) 
{
       		int row1 = 3, col1 = 2;
        		int row2 = 3, col2 = 2;
        		int[][] firstMatrix = { {1, -3,1}, {4, 1, 0} };
        		int[][] secondMatrix = { {4, 2}, {1, -2}, {3, -1} };
int[][] result = multiplyMatrices(firstMatrix, secondMatrix, row1, col1, col2);
displayProduct(result);
    	}

public static int[][] multiplyMatrices(int[][] firstMatrix, int[][] secondMatrix, int row1, int col1, int col2) 
                {
        		int[][] result = new int[row1][col2];
        		for(int i = 0; i < row1; i++) 
                       {
            			for (int j = 0; j < col2; j++) 
                          {
                			for (int k = 0; k < col1; k++) 
                                 {
                    				result[i][j] += firstMatrix[i][k] * secondMatrix[k][j];
                	        		}
            		    	}
       	 	             }
                  return result;
               	}
public static void displayProduct(int[][] product) 
               {
        		System.out.println("Product of the matrices is: ");
        		for(int[] row : product) 
                     {
            			for (int column : row) 
                          {
                			System.out.print(column + "    ");
            			  }
            			System.out.println();
             		}
    	        }
}