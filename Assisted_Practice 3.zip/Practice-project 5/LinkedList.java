package assistedPractice;

public class LinkedList {
	Node head;

	static class Node {
		int data;
		Node next;

		Node(int d) {
			data = d;
			next = null;
		}
	}

	public static LinkedList insert(LinkedList list, int data) {

		Node new_node = new Node(data);

		if (list.head == null) {
			list.head = new_node;
		}
		else
		{
			Node last;
			for(last=list.head;last.next!=null;last=last.next){}
			last.next=new_node;
		}
		return list;
	}
		
	
	public static LinkedList deleteByKey(LinkedList list, int key) {
		
		Node currnode=list.head, prev=null;
		if(currnode!=null && currnode.data==key){
			list.head=currnode.next;
			System.out.println( " found and deleted"+key);
		}
		else{
		while (currnode != null && currnode.data != key) {
			prev = currnode;
			currnode = currnode.next;
		}
		
		
		if (currnode != null) {
			prev.next = currnode.next;
			System.out.println(key+ " is found and deleted" );
		}
		if(currnode==null)
			System.out.println(key+" is not found");
		
		}
		return list;
	}
	
	
	
	
	
		public static void print(LinkedList list){
			
			for(Node last=list.head;last!=null;last=last.next){
				
				System.out.print(last.data+" ");
				
			}
			System.out.println();
		}
		
		
		
	public static void main(String[] args) {
		LinkedList list = new LinkedList();
		
		list = insert(list, 1);
		list = insert(list, 2);
		list = insert(list, 3);
		list = insert(list, 4);
		list = insert(list, 5);
		list = insert(list, 6);
		list = insert(list, 7);
		list = insert(list, 8);
		print(list);
		list=deleteByKey(list,4);
		print(list);
		list=deleteByKey(list,7);
		print(list);
		list=deleteByKey(list,10);
		print(list);
	}
}