package assistedPractice;

public class Queue {
public static void main(String[] args) 
       {
        		Queue <String>Name = new LinkedList<>();
                Name.add("Kolkata");
        		Name.add("Patna");
        		Name.add("Delhi");
        		Name.add("Gurgaon");
        		Name.add("Noida");
                System.out.println("Queue is : " + Name);
        		System.out.println("Head of Queue : " + Name.peek());
        		Name.remove();
        		System.out.println("After removing Head of Queue : " + Name);
        		System.out.println("Size of Queue : " + Name.size());
    	}
}