package assistedPractice4;

import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {
		int arr[]={13,59,22,31,18,97,73};
		int n=arr.length;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a value to be searched");
		int key=sc.nextInt();
		boolean found=false;
		for(int i=0;i<n;i++){
			if(arr[i]==key){
				found=true;
				break;
			}
			
		}
		if(found==true)	
		    System.out.println("Value is present");
		
		else
			System.out.println("Value is not present");

	}
}