package assistedPractice4;

import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {
		int arr[] = { 45, 67, 23, 89, 9 };
		SelectionSort.sort(arr);
		for(int i=0;i<arr.length;i++){
			System.out.print(arr[i]+" ");
		}
		Scanner scan=new Scanner(System.in);
		System.out.println("\nEnter a value to be searched:");
		int value=scan.nextInt();
		
		boolean ans=binarySearching(arr,value);
		if(ans)
			System.out.println("The value is present");
		else
			System.out.println("The value is not present");

	}
	
	public static boolean binarySearching(int arr[],int value){
		boolean ans=false;
		int start=0;
		int end=arr.length-1;
		int mid;
		while(start<=end){
			mid=(start+end)/2;
			if(arr[mid]==value){
				ans=true; break;
			}
			else
				if(arr[mid]<value)
					start=mid+1;
				else
					end=mid-1;
				
		}
		
	return ans;
	}

}