package assistedPractice4;

import java.util.Arrays;

public class ExponentialSearch {
	
public static void main(String[] args){

    int[] arr = {11,5,21,13,4,42};
    int length= arr.length;
    int val = 21;
    int result = exponentialSearch(arr,length,val);

    if(result<0){

       System.out.println( "Element is not present in the array");

    }else {

        System.out.println( "Element is  present in the array at index :"+result);
    }

        }

        public static int exponentialSearch(int[] arr ,int length, int val){

        if(arr[0]==val){
            return 0;
            }
        int i=1;
        while(i<length && arr[i]<=val){

            i=i*2;
        }
        return Arrays.binarySearch(arr,i/2,Math.min(i,length),val);
        }


}